import json
import os
import time
import xbmcvfs

STORE = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.batclan/resume.json")

def _load():
    if not xbmcvfs.exists(STORE):
        return {}
    with xbmcvfs.File(STORE) as f:
        try:
            return json.loads(f.read())
        except Exception:
            return {}

def _save(data):
    xbmcvfs.mkdirs(os.path.dirname(STORE))
    with xbmcvfs.File(STORE, "w") as f:
        f.write(json.dumps(data))

def _key(viewer, item_id):
    return f"{viewer}:{item_id}"

def set(viewer, item_id, label, art, mediatype, position, total):
    data = _load()
    data[_key(viewer, item_id)] = {
        "viewer": viewer,
        "item_id": item_id,
        "label": label,
        "art": art,
        "mediatype": mediatype,
        "position": position,
        "total": total,
        "updated": int(time.time())
    }
    _save(data)

def clear(viewer, item_id):
    data = _load()
    k = _key(viewer, item_id)
    if k in data:
        del data[k]
        _save(data)

def all(viewer, limit=50):
    data = _load()
    rows = [v for v in data.values() if v.get("viewer") == viewer]
    rows.sort(key=lambda x: x.get("updated", 0), reverse=True)
    return rows[:limit]
