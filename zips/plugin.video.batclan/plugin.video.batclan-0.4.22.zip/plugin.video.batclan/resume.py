import json
import os
import time
import urllib.request
import urllib.parse

RESUME_URL = "http://asus:7788"
LOCAL_FILE = "resume_local.json"

def _load_local():
    if not os.path.exists(LOCAL_FILE):
        return {}
    with open(LOCAL_FILE, "r") as f:
        return json.load(f)

def _save_local(data):
    with open(LOCAL_FILE, "w") as f:
        json.dump(data, f)

def _http_post(path, payload):
    req = urllib.request.Request(
        RESUME_URL + path,
        data=json.dumps(payload).encode(),
        headers={"Content-Type": "application/json"},
        method="POST"
    )
    urllib.request.urlopen(req, timeout=2).read()

def _http_get(path, params):
    url = RESUME_URL + path + "?" + urllib.parse.urlencode(params)
    with urllib.request.urlopen(url, timeout=2) as r:
        return json.loads(r.read())

def set(item_id, label, art, mediatype, position, total, viewer, audience="adult"):
    payload = {
        "viewer": viewer,
        "item_id": item_id,
        "label": label,
        "art": art,
        "mediatype": mediatype,
        "position": position,
        "total": total,
        "audience": audience
    }
    try:
        _http_post("/resume/set", payload)
    except Exception:
        data = _load_local()
        data[item_id] = {**payload, "updated": int(time.time())}
        _save_local(data)

def clear(item_id, viewer):
    try:
        _http_post("/resume/clear", {"viewer": viewer, "item_id": item_id})
    except Exception:
        data = _load_local()
        if item_id in data:
            del data[item_id]
            _save_local(data)

def all(viewer, limit=50, audience=None):
    try:
        params = {"viewer": viewer, "limit": limit}
        if audience:
            params["audience"] = audience
        return _http_get("/resume/all", params)
    except Exception:
        data = _load_local()
        rows = list(data.items())
        rows.sort(key=lambda r: r[1]["updated"], reverse=True)
        return rows[:limit]

