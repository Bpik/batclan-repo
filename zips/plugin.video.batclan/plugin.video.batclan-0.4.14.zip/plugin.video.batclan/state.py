import xbmc
import xbmcgui
import xbmcaddon

ADDON = xbmcaddon.Addon()
ID = ADDON.getAddonInfo("id")

def _get(k):
    return ADDON.getSetting(k)

def _set(k, v):
    ADDON.setSetting(k, v)

def get_active_viewer():
    return _get("active_viewer")

def set_active_viewer(viewer):
    policy = _get("device_policy")
    if policy == "locked_kids":
        _set("active_viewer", "Aya")
        _set("device_mode", "kids")
        return
    _set("active_viewer", viewer)
    if viewer == "Aya":
        _set("device_mode", "kids")

def get_device_mode():
    policy = _get("device_policy")
    if policy == "locked_kids":
        return "kids"
    return _get("device_mode")

def set_device_mode(mode):
    policy = _get("device_policy")
    if policy == "locked_kids":
        _set("device_mode", "kids")
        return

    if mode == "adult" and _get("device_mode") == "kids":
        if not _require_pin():
            return

    _set("device_mode", mode)

def _require_pin():
    pin = _get("kids_exit_pin")
    if not pin:
        return True

    kb = xbmc.Keyboard("", "Enter PIN")
    kb.doModal()
    if not kb.isConfirmed():
        return False
    return kb.getText() == pin

def ensure_session_viewer():
    policy = _get("device_policy")
    if policy != "guarded":
        return

    win = xbmcgui.Window(10000)
    if win.getProperty("batclan.session.initialised") == "true":
        return

    viewer = _select_viewer()
    if viewer:
        set_active_viewer(viewer)

    win.setProperty("batclan.session.initialised", "true")


def _select_viewer():
    options = ["Benjamin", "Tamanna", "Aya", "Clan"]
    dialog = xbmcgui.Dialog()
    idx = dialog.select("Who's watching?", options)
    if idx < 0:
        return None
    return options[idx]
