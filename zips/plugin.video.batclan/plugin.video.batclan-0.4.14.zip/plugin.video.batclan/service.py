import xbmc
import state

def run():
    try:
        state.ensure_session_viewer()
    except Exception:
        pass

monitor = xbmc.Monitor()
run()
while not monitor.abortRequested():
    if monitor.waitForAbort(3600):
        break
