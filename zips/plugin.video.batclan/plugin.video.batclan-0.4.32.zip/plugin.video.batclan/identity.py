import os
import json
import xbmcvfs
import xbmcgui

ADDON_ID = "plugin.video.batclan"
_IDENTITY = None


def _identity_path():
    base = xbmcvfs.translatePath(f"special://profile/addon_data/{ADDON_ID}")
    if not os.path.exists(base):
        os.makedirs(base, exist_ok=True)
    return os.path.join(base, "identity.json")


def _prompt(heading, default=""):
    return xbmcgui.Dialog().input(heading, default=default)


def load_identity():
    global _IDENTITY
    if _IDENTITY is not None:
        return _IDENTITY

    path = _identity_path()

    if os.path.exists(path):
        try:
            with open(path, "r") as f:
                _IDENTITY = json.load(f)
        except Exception:
            raise RuntimeError("identity.json is invalid JSON")

        if "viewer" not in _IDENTITY or "jellyfin_user_id" not in _IDENTITY:
            raise RuntimeError("identity.json missing required keys")

        return _IDENTITY

    dlg = xbmcgui.Dialog()
    dlg.ok(
        "Batclan Media – First-time setup",
        "This Kodi profile must be linked to a Jellyfin user.\n\n"
        "You will be asked for:\n"
        "• Viewer name\n"
        "• Jellyfin User ID"
    )

    viewer = _prompt("Viewer name (e.g. Benjamin, Tamanna, Aya, Clan)").strip()
    if not viewer:
        dlg.ok("Batclan Media", "Viewer name is required.")
        raise RuntimeError("Viewer not set")

    jellyfin_user_id = _prompt("Jellyfin User ID").strip()
    if not jellyfin_user_id:
        dlg.ok("Batclan Media", "Jellyfin User ID is required.")
        raise RuntimeError("Jellyfin user not set")

    _IDENTITY = {
        "viewer": viewer,
        "jellyfin_user_id": jellyfin_user_id
    }

    with open(path, "w") as f:
        json.dump(_IDENTITY, f, indent=2)

    dlg.ok(
        "Batclan Media",
        f"Profile linked successfully.\n\nViewer: {viewer}"
    )

    return _IDENTITY
