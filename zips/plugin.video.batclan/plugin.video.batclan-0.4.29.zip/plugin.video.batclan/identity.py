import os
import json
import xbmcvfs
import xbmcgui

ADDON_ID = "plugin.video.batclan"

def _identity_path():
    base = xbmcvfs.translatePath(f"special://profile/addon_data/{ADDON_ID}")
    if not os.path.exists(base):
        os.makedirs(base, exist_ok=True)
    return os.path.join(base, "identity.json")

def _prompt(title, default=""):
    return xbmcgui.Dialog().input(title, defaultt=default)

def _error(msg):
    xbmcgui.Dialog().ok("Batclan Media", msg)

def load_identity():
    path = _identity_path()

    if os.path.exists(path):
        with open(path, "r") as f:
            return json.load(f)

    dlg = xbmcgui.Dialog()

    dlg.ok(
        "Batclan Media – First-time setup",
        "This profile needs to be linked to a Jellyfin user."
    )

    viewer = _prompt("Viewer name (e.g. Ben, Aya)")
    if not viewer:
        _error("Viewer name is required.")
        raise RuntimeError("Viewer not set")

    jellyfin_user_id = _prompt("Jellyfin User ID")
    if not jellyfin_user_id:
        _error("Jellyfin User ID is required.")
        raise RuntimeError("Jellyfin user not set")

    identity = {
        "viewer": viewer,
        "jellyfin_user_id": jellyfin_user_id
    }

    with open(path, "w") as f:
        json.dump(identity, f, indent=2)

    dlg.ok(
        "Batclan Media",
        f"Profile linked as:\n\nViewer: {viewer}"
    )

    return identity
