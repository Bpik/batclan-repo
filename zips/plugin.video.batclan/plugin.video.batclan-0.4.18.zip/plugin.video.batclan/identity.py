import os
import json
import xbmc

_IDENTITY = None

def load_identity():
    global _IDENTITY
    if _IDENTITY is not None:
        return _IDENTITY

    base = xbmc.translatePath(
        "special://profile/addon_data/plugin.video.batclan"
    )
    path = os.path.join(base, "identity.json")

    if not os.path.exists(path):
        raise Exception("identity.json not found for active profile")

    with open(path, "r") as f:
        _IDENTITY = json.load(f)

    if "jellyfin_user_id" not in _IDENTITY:
        raise Exception("identity.json missing jellyfin_user_id")

    return _IDENTITY

