import sys
import json
import urllib.parse
import urllib.request
import xbmc
import xbmcgui
import xbmcplugin

import state
from resume import set as resume_set, clear as resume_clear, all as resume_all
from identity import load_identity

HANDLE = int(sys.argv[1])
ARGS = sys.argv[2]

JELLYFIN_HOST = "http://192.168.10.122:8096"
API_KEY = "1e484ab768c0400a97572c3d31ece3c0"
CLIENT = "batclan-kodi"

IDENTITY = load_identity()
USER_ID = IDENTITY["jellyfin_user_id"]
VIEWER = IDENTITY["viewer_id"]

LIB_MOVIES = "f137a2dd21bbc1b99aa5c0f6bf02a805"
LIB_TV = "4514ec850e5ad0c47b58444e17b6346c"
LIB_KIDS_MOVIES = "384bb658bdd82344138c376d0e4945c0"
LIB_KIDS_TV = "f59d130de19731a61863f59d47783782"

HEADERS = {
    "X-Emby-Token": API_KEY,
    "X-Emby-Client": CLIENT
}

def _normalise_state():
    policy = state._get("device_policy")
    if policy == "locked_kids":
        state.set_active_viewer("Aya")
        state.set_device_mode("kids")

def jellyfin_get(path):
    req = urllib.request.Request(JELLYFIN_HOST + path, headers=HEADERS)
    with urllib.request.urlopen(req) as r:
        return json.loads(r.read())

def jellyfin_post(path):
    req = urllib.request.Request(JELLYFIN_HOST + path, headers=HEADERS, method="POST")
    urllib.request.urlopen(req).close()

def plugin_url(params):
    return "plugin://plugin.video.batclan/?" + urllib.parse.urlencode(params)

def item_art(item_id):
    return f"{JELLYFIN_HOST}/Items/{item_id}/Images/Primary?api_key={API_KEY}"

def decorate_userdata(li, item):
    ud = item.get("UserData") or {}
    if ud.get("Played"):
        li.setProperty("IsWatched", "true")

    resume_ticks = ud.get("PlaybackPositionTicks") or 0
    runtime_ticks = item.get("RunTimeTicks") or 0

    if resume_ticks > 0 and runtime_ticks > 0 and resume_ticks < runtime_ticks:
        li.setProperty("resumetime", str(resume_ticks // 10_000_000))
        li.setProperty("totaltime", str(runtime_ticks // 10_000_000))

def add_folder(label, params):
    li = xbmcgui.ListItem(label=label)
    xbmcplugin.addDirectoryItem(HANDLE, plugin_url(params), li, isFolder=True)

def add_playable(item, params, mediatype):
    name = item.get("Name", "")
    year = item.get("ProductionYear")

    if mediatype == "movie" and year:
        label = f"{name} ({year})"
    else:
        label = name

    li = xbmcgui.ListItem(label=label)
    li.setProperty("IsPlayable", "true")
    li.setInfo("video", {"title": name, "mediatype": mediatype})
    art = item_art(item["Id"])
    li.setArt({"poster": art, "thumb": art, "fanart": art})
    decorate_userdata(li, item)
    xbmcplugin.addDirectoryItem(HANDLE, plugin_url(params), li, isFolder=False)

def root():
    add_folder("Continue Watching", {"action": "continue_all"})
    add_folder("Next Up", {"action": "continue_watching"})
    add_folder("Kids Next Up", {"action": "continue_watching_kids"})
    add_folder("Finish Up", {"action": "finish_up_adult"})
    add_folder("Kids Finish Up", {"action": "finish_up_kids"})
    add_folder("Movies", {"action": "movies"})
    add_folder("TV", {"action": "tv"})
    add_folder("Kids Movies", {"action": "kids_movies"})
    add_folder("Kids TV", {"action": "kids_tv"})
    xbmcplugin.endOfDirectory(HANDLE)

def list_movies(parent_id):
    data = jellyfin_get(
        f"/Users/{USER_ID}/Items"
        f"?ParentId={parent_id}"
        f"&IncludeItemTypes=Movie"
        f"&Recursive=true"
        f"&Fields=UserData,RunTimeTicks,ProductionYear"
    )
    for item in data.get("Items", []):
        add_playable(item, {"action": "play", "item": item["Id"]}, "movie")
    xbmcplugin.endOfDirectory(HANDLE)

def list_series(parent_id):
    data = jellyfin_get(
        f"/Users/{USER_ID}/Items"
        f"?ParentId={parent_id}"
        f"&IncludeItemTypes=Series"
        f"&Fields=UserData"
    )
    for item in data.get("Items", []):
        li = xbmcgui.ListItem(label=item.get("Name", ""))
        li.setInfo("video", {"title": item.get("Name", ""), "mediatype": "tvshow"})
        art = item_art(item["Id"])
        li.setArt({"poster": art, "thumb": art, "fanart": art})
        decorate_userdata(li, item)
        xbmcplugin.addDirectoryItem(
            HANDLE,
            plugin_url({"action": "seasons", "series": item["Id"]}),
            li,
            isFolder=True
        )
    xbmcplugin.endOfDirectory(HANDLE)

def kids_series_ids():
    data = jellyfin_get(
        f"/Users/{USER_ID}/Items"
        f"?ParentId={LIB_KIDS_TV}"
        f"&IncludeItemTypes=Series"
        f"&Fields=Id"
    )
    return {item["Id"] for item in data.get("Items", [])}

def list_seasons(series_id):
    data = jellyfin_get(
        f"/Users/{USER_ID}/Items"
        f"?ParentId={series_id}"
        f"&IncludeItemTypes=Season"
        f"&Fields=UserData"
    )
    for item in data.get("Items", []):
        li = xbmcgui.ListItem(label=item.get("Name", ""))
        li.setInfo("video", {"title": item.get("Name", ""), "mediatype": "season"})
        xbmcplugin.addDirectoryItem(
            HANDLE,
            plugin_url({"action": "episodes", "season": item["Id"]}),
            li,
            isFolder=True
        )
    xbmcplugin.endOfDirectory(HANDLE)

def list_episodes(season_id):
    data = jellyfin_get(
        f"/Users/{USER_ID}/Items"
        f"?ParentId={season_id}"
        f"&IncludeItemTypes=Episode"
        f"&Recursive=true"
        f"&Fields=UserData,RunTimeTicks,IndexNumber,ParentIndexNumber,SeriesName"
    )
    for item in data.get("Items", []):
        season = item.get("ParentIndexNumber")
        episode = item.get("IndexNumber")
        title = item.get("Name", "")

        if season is not None and episode is not None:
            label = f"S{int(season):02d}E{int(episode):02d} – {title}"
        else:
            label = title

        item2 = dict(item)
        item2["Name"] = label

        add_playable(item2, {"action": "play", "item": item2["Id"]}, "episode")
    xbmcplugin.endOfDirectory(HANDLE)

def continue_all():
    xbmcplugin.setContent(HANDLE, "videos")
    xbmcplugin.setPluginCategory(HANDLE, "Continue Watching")

    add_folder("Finish Up", {"action": "continue_resume"})
    add_folder("Next Up", {"action": "continue_watching"})

    xbmcplugin.endOfDirectory(HANDLE)

def continue_watching():
    kids_ids = kids_series_ids()

    data = jellyfin_get(
        f"/Shows/NextUp"
        f"?UserId={USER_ID}"
        f"&Limit=50"
        f"&Fields=UserData,RunTimeTicks,IndexNumber,ParentIndexNumber,SeriesName,SeriesId"
    )

    for item in data.get("Items", []):
        if item.get("SeriesId") in kids_ids:
            continue

        series = item.get("SeriesName") or ""
        season = item.get("ParentIndexNumber")
        episode = item.get("IndexNumber")
        title = item.get("Name", "")

        label = (
            f"{series} — S{int(season):02d}E{int(episode):02d} – {title}"
            if season is not None and episode is not None
            else title
        )

        item2 = dict(item)
        item2["Name"] = label

        add_playable(item2, {"action": "play", "item": item2["Id"]}, "episode")

    xbmcplugin.endOfDirectory(HANDLE)

def continue_watching_kids():
    kids_ids = kids_series_ids()

    data = jellyfin_get(
        f"/Shows/NextUp"
        f"?UserId={USER_ID}"
        f"&Limit=50"
        f"&Fields=UserData,RunTimeTicks,IndexNumber,ParentIndexNumber,SeriesName,SeriesId"
    )

    for item in data.get("Items", []):
        if item.get("SeriesId") not in kids_ids:
            continue

        series = item.get("SeriesName") or ""
        season = item.get("ParentIndexNumber")
        episode = item.get("IndexNumber")
        title = item.get("Name", "")

        label = (
            f"{series} — S{int(season):02d}E{int(episode):02d} – {title}"
            if season is not None and episode is not None
            else title
        )

        item2 = dict(item)
        item2["Name"] = label

        add_playable(item2, {"action": "play", "item": item2["Id"]}, "episode")

    xbmcplugin.endOfDirectory(HANDLE)

def continue_resume():
    xbmcplugin.setContent(HANDLE, "videos")
    xbmcplugin.setPluginCategory(HANDLE, "Continue Watching")

    rows = resume_all(50, VIEWER)

    if not rows:
        li = xbmcgui.ListItem(label="Nothing to continue")
        xbmcplugin.addDirectoryItem(HANDLE, "", li, False)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    for item_id, data in rows:
        label = data.get("label") or item_id
        art = data.get("art") or item_art(item_id)
        mediatype = data.get("mediatype") or "video"

        li = xbmcgui.ListItem(label=label)
        li.setProperty("IsPlayable", "true")
        li.setInfo("video", {"title": label, "mediatype": mediatype})
        li.setArt({"poster": art, "thumb": art, "fanart": art, "icon": art})
        li.setProperty("ResumeTime", str(int(data.get("position", 0) or 0)))
        li.setProperty("TotalTime", str(int(data.get("total", 0) or 0)))

        xbmcplugin.addDirectoryItem(
            HANDLE,
            plugin_url({"action": "play", "item": item_id}),
            li,
            False
        )

    xbmcplugin.endOfDirectory(HANDLE)

def finish_up_adult():
    show_finish_up("adult")

def finish_up_kids():
    show_finish_up("kids")

def show_finish_up(audience):
    xbmcplugin.setContent(HANDLE, "videos")
    rows = resume_all(50, VIEWER, audience)

    if not rows:
        li = xbmcgui.ListItem(label="Nothing to finish")
        xbmcplugin.addDirectoryItem(HANDLE, "", li, False)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    for item_id, data in rows:
        li = xbmcgui.ListItem(label=data["label"])
        li.setProperty("IsPlayable", "true")
        li.setInfo("video", {"title": data["label"], "mediatype": data["mediatype"]})
        art = data["art"]
        li.setArt({"poster": art, "thumb": art, "fanart": art})
        li.setProperty("ResumeTime", str(int(data["position"])))
        li.setProperty("TotalTime", str(int(data["total"])))

        xbmcplugin.addDirectoryItem(
            HANDLE,
            plugin_url({"action": "play", "item": item_id}),
            li,
            False
        )

    xbmcplugin.endOfDirectory(HANDLE)

def play_item(item_id):
    info = None
    try:
        info = jellyfin_get(
            f"/Users/{USER_ID}/Items/{item_id}"
            f"?Fields=ProductionYear,IndexNumber,ParentIndexNumber,SeriesName"
        )
    except Exception:
        info = {}

    label = item_id
    mediatype = "video"

    t = (info.get("Type") or "").lower()
    if t == "movie":
        mediatype = "movie"
        name = info.get("Name") or item_id
        year = info.get("ProductionYear")
        label = f"{name} ({year})" if year else name
    elif t == "episode":
        mediatype = "episode"
        series = info.get("SeriesName") or ""
        season = info.get("ParentIndexNumber")
        episode = info.get("IndexNumber")
        title = info.get("Name") or item_id
        ep_label = f"S{int(season):02d}E{int(episode):02d} – {title}" if season is not None and episode is not None else title
        label = f"{series} — {ep_label}" if series else ep_label
    else:
        name = info.get("Name") or item_id
        label = name

    li = xbmcgui.ListItem(path=f"{JELLYFIN_HOST}/Videos/{item_id}/stream?static=true|X-Emby-Token={API_KEY}")
    li.setProperty("IsPlayable", "true")
    xbmcplugin.setResolvedUrl(HANDLE, True, li)

    p = xbmc.Player()
    m = xbmc.Monitor()

    started = False
    last_pos = 0.0
    total = 0.0

    while not m.abortRequested():
        if p.isPlaying():
            started = True
            try:
                last_pos = p.getTime()
                total = p.getTotalTime()
            except Exception:
                pass
            if m.waitForAbort(0.5):
                break
        else:
            if started:
                break
            if m.waitForAbort(0.1):
                break

    if total and total > 0:
        if (last_pos / total) >= 0.9:
            resume_clear(item_id, VIEWER)
            try:
                jellyfin_post(f"/Users/{USER_ID}/PlayedItems/{item_id}")
            except Exception:
                pass
        else:
            audience = "adult"

            if mediatype == "movie":
                parent = info.get("ParentId")
                if parent == LIB_KIDS_MOVIES:
                    audience = "kids"

            elif mediatype == "episode":
                series_id = info.get("SeriesId")
                if series_id and series_id in kids_series_ids():
                    audience = "kids"

            resume_set(
                item_id,
                label,
                item_art(item_id),
                mediatype,
                last_pos,
                total,
                VIEWER,
                audience
            )

params = dict(urllib.parse.parse_qsl(ARGS[1:]))
action = params.get("action")

_normalise_state()
state.ensure_session_viewer()

if action == "continue_watching":
    continue_watching()
elif action == "continue_watching_kids":
    continue_watching_kids()
elif action == "continue_resume":
    continue_resume()
elif action == "finish_up_adult":
    finish_up_adult()
elif action == "finish_up_kids":
    finish_up_kids()
elif action == "movies":
    list_movies(LIB_MOVIES)
elif action == "tv":
    list_series(LIB_TV)
elif action == "kids_movies":
    list_movies(LIB_KIDS_MOVIES)
elif action == "kids_tv":
    list_series(LIB_KIDS_TV)
elif action == "seasons" and "series" in params:
    list_seasons(params["series"])
elif action == "episodes" and "season" in params:
    list_episodes(params["season"])
elif action == "play" and "item" in params:
    play_item(params["item"])
elif action == "continue_all":
    continue_all()
else:
    root()
